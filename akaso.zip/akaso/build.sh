#!/bin/bash
cd ../..

# copy firebase files
cp -f config/akaso/firebase/google-services.json android/app/
cp -f config/akaso/firebase/GoogleService-Info.plist ios/Runner/
cp -f config/akaso/firebase/firebase_app_id_file.json ios/
cp -f config/akaso/firebase/firebase_options.dart lib/

# remove existing assets/config
rm -R assets/config/
# create assets/config directory
mkdir assets/config
# copy features to assets
cp -R -f config/akaso/assets/features.json assets/config/
# copy res to assets
cp -R config/akaso/assets/res/ assets/config/res/

# flutter
flutter pub get
dart run build_runner build -d

